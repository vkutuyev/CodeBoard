app.controller('LobbyController', function($scope) {
    
})
