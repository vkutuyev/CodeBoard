$(document).ready(function() {
    var socket = io.connect();
})
