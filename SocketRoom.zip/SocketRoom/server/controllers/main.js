// mongoose
// var mongoose = require('mongoose');
//Retreive the User mongoose object

//Model Call
// var Model = mongoose.model('Model');

//Module Export
module.exports = (function() {
    return {
        index: function(req, res) {
            console.log('Index');
        }
    }
})();
